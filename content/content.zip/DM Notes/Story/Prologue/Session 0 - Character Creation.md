---
tags:
  - Session
---

# Overview
Players are here to collaboratively create their characters and are given some setting background.

# Information Supplied
- Culture Overview Pages (History and Lore censored)
- Religion Overview Pages (History and Lore censored)
- Language Overview Pages (History and Lore censored)
- Solaum Elemental Politics (History and Lore censored)
- Solaum Race Poltiics (History and Lore censored)

# Limitations on Player Characters
## Languages
Player Characters are not allowed to be fully proficient in [[Solari (Language)|Solari]], but they are allowed to understand it. They are also not allowed to understand the following languages, though exceptions may apply:
- [[Aeikas]],
- [[Ebibu]],
- [[Ek]]
## Cultures
Player Characters are not allowed to be [[Setting/Cultures/Solari|Solari]], [[Setting/Cultures/Qatha]], [[Setting/Cultures/Aeia]], or [[Setting/Cultures/Kufa]]. Players are encouraged to be of a [[Setting/Cultures/Freiburg]] OR [[Setting/Cultures/Dulegan]] culture.
## Race
Due to race politics in [[Solara]] the player characters are allowed to be whatever race they want, but they have to be humanoid and have to have a good disguise to make them appear human at all times. Elves, dwarves and halflings do not have this limitation but may be seen as lesser and an oddity.
## Elements
All players will be assigned an element at random. They are aware of their powers and which powers they have, but not which one others players have. [[Setting/Elements/index|Elements]] and [[Setting/Elements/index|elementals]] are outlawed in Solara, there is also rampant propaganda, and players are aware of this. All magic is also outlawed in Solara unless a person has a [[License to use Magic|magic license]].