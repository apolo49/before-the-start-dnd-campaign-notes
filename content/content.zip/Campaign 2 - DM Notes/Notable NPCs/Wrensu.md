>[!infobox|wikipedia]
># Wrensu
>_Rogue NPC_
>INSERT IMAGE HERE
>Born: [[Dating|9th of Flami 1737 IOG]] (age 44), [[Amphos]], [[Eastern Solaran Empire]]
>Background: Criminal
>Race: Goliath
>Relatives: [[Riley]] (Adoptive Son)
