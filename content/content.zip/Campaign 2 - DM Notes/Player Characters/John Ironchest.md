>[!infobox|wikipedia]
># John Ironchest
>_FIghter_
>INSERT IMAGE HERE
>Born: [[Wiesen]], [[Duchy of ]]
>Class: Fighter 3, Eldritch Knight
>Background: Entertainer
>Race: Human
>Languages: [[Common]] (Literate, Fluent when Spoken), [[Aeikas]] (modern) (Literate, Fluent when Spoken) 
>Relatives: Unnamed Father
>Element: [[Power]]