>[!infobox|wikipedia]
># Evangeline Marquis, Princess of Eivia
>_Cleric_
>INSERT IMAGE HERE
>Born: [[Sassux]], [[Eivia|Kingdom of Eivia]]
>Class: Cleric 3
>Background: Noble
>Race: Human
>Languages: [[Solari (Language)|Solari]] (classical) (Literate), [[Common]] (Literate, Fluent when Spoken), [[Aeikas]] (classical and modern) (Literate, Fluent when Spoken) 
>Relatives: Unnamed Father
>Element: [[Earth]]

# Astragalomancy Prophecy
**[[Mashokamue]]** - You stand upon a peak, but its foundation is made of your fallen brethren. To achieve your goals, you must walk across the soil that covers your friends. Their sacrifice is the only thing keeping you above the mud.