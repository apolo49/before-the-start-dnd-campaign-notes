---
aliases:
  - Ellowen Aurelian Vale
  - Ellowen of Brackenfall
title: Ellowen Aurelian Vale
---
>[!infobox|wikipedia]
># Ellowen Aurelian Vale of Brackenfall
>_Wizard_
>INSERT IMAGE HERE
>Born: [[Dating|8th of Atmi 1758 IOG]] (age 23), [[Wiesen]], [[Duchy of Brackenfall]]
>Class: Wizard 3
>Background: Noble
>Race: Half-Elf
>Languages: [[Solari (Language)|Solari]] (classical) (Literate), [[Common]] (Literate, Fluent when Spoken), [[Aeikas]] (classical and modern) (Literate, Fluent when Spoken) 
>Relatives: Unnamed Father
>Element: [[Water]]
# Astragalomancy Prophecy
**[[Danu]]** - Light fades as you sink into a blue so dark it is black. There is no bottom to hit, only the terrifying realization that you are falling through a liquid void where time and breath have no meaning.